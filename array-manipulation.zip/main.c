#include <stdio.h>

int main()
{ 
    int arr[]={1,2,3,4,5,6};
    int i,len;
    len=sizeof(arr)/sizeof(arr[0]);
    for(i=0;i<len;i++){
        if(i%2==0){
            
          
    printf("%d",arr[i]);
  
        }
    }
  

    return 0;
}