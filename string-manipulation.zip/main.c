#include <stdio.h>
#include <string.h>
int main()
{   
    int i;
      char s[]="hello world";    
        char ch='o';                
     int len=strlen(s);
     for(i=0;i<=len;i++){     
        if(s[i]!=ch){
            
          printf("%c",s[i]);
  
        }
    }
      

    return 0;
}
