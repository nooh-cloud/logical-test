#include <stdio.h>
int main()
{  
    int n,i,temp,j;
    
    printf("enter an array:");
    scanf("%d",&n);
    
    int my_array[n]; 
    
     printf("enter the numbers:");
    for(i=0;i<n;i++){
        scanf("%d",&my_array[i]);
        
    }
    for(i=0;i<n;i++){
        
        for(j=0;j<n-i-1;j++)
    
      {
        if(my_array[j]>my_array[j+1]){
            temp=my_array[j];
            my_array[j] =my_array[j+1];
            my_array[j+1]=temp;
        }
        
    }
    }
    printf("sorted array:\n");
       for(i=0;i<n;i++){
       printf("%d",my_array[i]);
}
    return 0;
}
